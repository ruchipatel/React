import './App.css';
import ExpenseDetail from './Componant/ExpenseDetail';
function App() {
  return (
    <div>
     <ExpenseDetail></ExpenseDetail>
     <ExpenseDetail></ExpenseDetail>
     <ExpenseDetail></ExpenseDetail>
     <ExpenseDetail></ExpenseDetail>
     <ExpenseDetail></ExpenseDetail>
     <ExpenseDetail></ExpenseDetail>
     </div>
  );
}

export default App;
